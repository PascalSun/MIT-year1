The Assignment1.sh include all files and commands to finish the Assignment1

The first task, I use three ways, because I use the os-x system, so the way1 need to install brew and coreutils

To see the outcome, just change to pwd, and input the command next

chmod +x Assignment1.sh
./Assignment1.sh





